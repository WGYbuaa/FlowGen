这个文件夹中的数据，
是在找tp node的过程中，发现没有将所有node的单词小写，导致tp非常少。
后期将tp都小写了。



_obj.json的文件是再往上一个版本，发现了如下问题：
        # Ernie_pub_pred_node.json中的pred obj node 出现了问题，修改了prompt（entity改为noun）之后重新跑得在Ernie_pub_pred_node_obj.json
        # 但是pred act没有改。