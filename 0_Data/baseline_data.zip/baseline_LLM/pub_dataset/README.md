1、
xxx_eval_1.json中的数据存在问题：
发现很多pred node没有提取出来。
然后发现是xxx_pred_node.json还正确，但是到str转list的时候，没有提取出来。
重新将没有转成list的部分转出来。

放在了xxx_eval.json文件中。



2、
xxx_pub_metric.json数据不同于xxx_pub.json,区别在于：
calculate_pub_metric_value_eval为calculate_pub_metric_value任务的改进，因为发现在训练rgat时，只有eval的数据展示，其他的uc作为train和test，metric数据不会被展示；所以baseline的数据也应该只输出作为eval的uc的。

所以全部数据的平均存放在了xxx_pub.json；仅计算eval数据集的结果存在了xxx_pub_metric.json。


3、
最终发现pub数据集的仅计算eval数据集的结果（xxx_pub_metric.json）由于数据量太小（包含分支流的uc太少），最终还是决定用xxx_pub.json
下的数据。等ncet数据集的时候，再看这两种数据哪个合适，用哪个。