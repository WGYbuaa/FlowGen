Standard_pub_alt_node.py 是使用斯坦福方法提取node，该文件用于 RQ1 的 RGAT with BERT (only RGAT)，
以及 RQ2 的 “without SIP”。