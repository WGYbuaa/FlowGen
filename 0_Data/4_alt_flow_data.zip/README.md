该文件夹下的内容，为融合了3_cleaned_json_dataset下的内容，即加上cleaned的分支流、异常流的数据；
和BFGen proj中的bf等数据（E:/GitHub/ASSAM/data/4_dataset_pred_node/ERNIE_4_Turbo_8k/with_tp/3rd_round/Ernie_pub.json），包括其中断句之后提取的node。