消融实验中，在不进行SIP Proc的情况下，分别对Ernie和GPT模型进行消融实验，即用这两个模型提取node。

此外，Standard_pub_alt_node.py 是使用斯坦福方法提取node，该文件用于 RQ1 的 RGAT with BERT (only RGAT)，
以及 RQ2 的 “without SIP”。

该文件夹下的用例的内容中的 alternative flow，
应该是比2_get_alt_node_after_SIP下的用例少一级列表，
因为没有拆分句子的步骤。


NCET数据集本身不参与SIP前面的两个task（不进行SIP），直接进行node提取。