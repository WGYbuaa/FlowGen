数据集来自：
E:\迅雷下载\traceability dataset\traceability dataset from coest.org\SMOS\SMOS\uc


修改了以下地方：

- SMOS52.txt - 文件中的"Nome: Ricerca Entita"和"Attori: Amministratore"被连在一起，没有换行，格式为"Nome: Ricerca EntitaAttori: Amministratore"。

- SMOS22.txt - "Sequenza degli eventi"部分的格式不规范，内容被分散在多行中，且排版混乱。
原文为：
Cerca	gli nell’archivio	e schermata	di insegnamenti
Visualizza insegnamenti
insegnamenti visualizza	la gestione	degli
l’elenco	degli


- SMOS34.txt - "Sequenza degli eventi"部分的系统事件描述被分散在多行中，且排版混乱
原文：1.	Mostra	tutte	le	assenze dell'alunno
registrate scolastico selezionato Le assenze già giustificate vengono
visualizzate in verde, quelle da giustificare in rosso
durante	l'anno