数据集来自：
E:\迅雷下载\traceability dataset\ftlr_Improving Traceability Link Recovery Using Fine-grained Requirements-to-Code Relations\datasets\eANCI\req

修改：

EA30.txt 增加“Requisiti di qualita”