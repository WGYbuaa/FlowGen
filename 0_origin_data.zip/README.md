Store the original dataset.
